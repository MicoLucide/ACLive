package com.example.aclive;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;



public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Establish ViewPager and attach to xml object
        ViewPager viewPager = (ViewPager) findViewById(R.id.viewpager);

        // Establish adapter for fragments
        com.example.aclive.CategoryAdapter adapter = new com.example.aclive.CategoryAdapter(getSupportFragmentManager());

        // Attach adapter to viewpager
        viewPager.setAdapter(adapter);

        // Attach TabLayout to viewPager
        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(viewPager);
        tabLayout.setTabTextColors(ColorStateList.valueOf(Color.parseColor("#ffffff")));
        tabLayout.setSelectedTabIndicatorColor(Color.parseColor("#ffffff"));
    }
}
