package com.example.aclive;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class CategoryAdapter extends FragmentPagerAdapter {
    final int PAGE_COUNT = 4;
    private String tabTitles[] = new String[]{"Local Food", "Landmarks", "Casinos", "Events"};
    private Context context;

    // Attribute fragment manager to adapter
    public CategoryAdapter(FragmentManager fm) {
        super(fm);
        this.context = context;
    }

    // Attributes Fragments to Positions/Establishes Tab Order
    @Override
    public Fragment getItem(int position) {
        if (position == 0) {
            return new LocalFoodFragment();
        } else if (position == 1) {
            return new LandmarksFragment();
        } else if (position == 2) {
            return new CasinosFragment();
        } else {
            return new EventsFragment();
        }
    }

    // Establish getter method for Fragments
    @Override
    public int getCount() {
        return PAGE_COUNT;
    }

    // Establish getter method for Titles
    @Override
    public CharSequence getPageTitle(int position) {
        return tabTitles[position];
    }
}
