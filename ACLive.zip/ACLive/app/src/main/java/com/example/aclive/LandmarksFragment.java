package com.example.aclive;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;


public class LandmarksFragment extends Fragment {

    public LandmarksFragment() {
        // Empty Public Constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.list_view, container, false);

        final ArrayList<Content> contents = new ArrayList<Content>();
        contents.add(new Content("Steel Pier", "1000 Boardwalk, \nAtlantic City, NJ 08401",
                R.drawable.ic_map_marker_black_36dp));
        contents.add(new Content("Absecon Lighthouse", "31 S Rhode Island Ave, \nAtlantic City, NJ 08401",
                R.drawable.ic_map_marker_black_36dp));
        contents.add(new Content("Boardwalk Hall", "2301 Boardwalk, \nAtlantic City, NJ 08401",
                R.drawable.ic_map_marker_black_36dp));
        contents.add(new Content("Ripley's Believe It or Not", "1441 Boardwalk, \nAtlantic City, NJ 08401",
                R.drawable.ic_map_marker_black_36dp));

        ContentAdapter adapter = new ContentAdapter(getActivity(), contents);

        ListView listView = (ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Content content = contents.get(position);
                Uri gmmIntentUri = Uri.parse("" + content.getAddress());
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });

        return rootView;
    }
}