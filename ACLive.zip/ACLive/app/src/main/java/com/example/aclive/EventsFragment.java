package com.example.aclive;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class EventsFragment extends Fragment {

        public EventsFragment() {
            // Empty Public Constructor
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.list_view, container, false);

            final ArrayList<Content> contents = new ArrayList<Content>();
            contents.add(new Content("Alanis Morissette Concert", "500 Boardwalk, \nAtlantic City, NJ 08401",
                    R.drawable.ic_local_activity_black_36dp));
            contents.add(new Content("First Dunk of the Season", "100 Boardwalk, \nAtlantic City, NJ 08401",
                    R.drawable.ic_local_activity_black_36dp));
            contents.add(new Content("Beer Crawl", "133 South Tennessee Ave., \nAtlantic City, NJ 08401",
                    R.drawable.ic_local_activity_black_36dp));

            ContentAdapter adapter = new ContentAdapter(getActivity(), contents);

            ListView listView = (ListView) rootView.findViewById(R.id.list);
            listView.setAdapter(adapter);

            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Content content = contents.get(position);
                    Uri gmmIntentUri = Uri.parse("" + content.getAddress());
                    Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                    mapIntent.setPackage("com.google.android.apps.maps");
                    startActivity(mapIntent);
                }
            });

            return rootView;
        }
    }