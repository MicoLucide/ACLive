package com.example.aclive;

public class Content {
    private String mTitle;
    private String mAddress;
    private int mImageIcon;

    // Create standard expected instance of Content
    public Content(String title, String address, int imageIcon) {
        mTitle = title;
        mAddress = address;
        mImageIcon = imageIcon;
    }

    // Create getter methods
    public String getTitle() {
        return mTitle;
    }
    public String getAddress() {
        return mAddress;
    }
    public int getImageIcon() {
        return mImageIcon; }

}
